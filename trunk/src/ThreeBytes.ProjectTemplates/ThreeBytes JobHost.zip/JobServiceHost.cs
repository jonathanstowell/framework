﻿using Bootstrap;
using Bootstrap.Extensions.StartupTasks;
using Castle.Windsor;
using ThreeBytes.Core.Bootstrapper.Extensions.Windsor;
using ThreeBytes.Core.Plugin.Abstract;
using ThreeBytes.Core.Plugin.Concrete;
using ThreeBytes.Core.Quartz.Abstract;
using ThreeBytes.Core.Quartz.Concrete;
using $safeprojectname$.Installers;
using Topshelf;

namespace $safeprojectname$
{
    public static class JobServiceHost
    {
        public static IResolveAssemblies AssemblyResolver = new ResolveAssemblies("Plugins", "ThreeBytes.*.dll");
        private static IWindsorContainer Container = new WindsorContainer();

        public static void Bootstrap()
        {
            Bootstrapper.With.Windsor(AssemblyResolver, BootstrapEnvironment.BUS).And.StartupTasks().UsingThisExecutionOrder(s => s
                        .First<AppDomainAssemblyResolverStartupTask>()
                        .Then<WindsorSetupStartupTask>()
                        .Then().TheRest()).Start();

            Container = (IWindsorContainer)Bootstrapper.Container;   
        }

        public static Host InitialiseHost()
        {
            return HostFactory.New(x =>
            {
                x.Service<IQuartzServer>(s =>
                {
                    s.SetServiceName("quartz.server");
                    s.ConstructUsing(builder =>
                    {
                        QuartzServer server = new QuartzServer(Container.ResolveAll<IRegisterQuartzJob>());
                        server.Initialize();
                        return server;
                    });
                    s.WhenStarted(server => server.Start());
                    s.WhenPaused(server => server.Pause());
                    s.WhenContinued(server => server.Resume());
                    s.WhenStopped(server => server.Stop());
                });

                x.RunAsLocalSystem();

                x.SetDescription("ThreeBytes Quartz Service");
                x.SetDisplayName("ThreeBytes Quartz Service");
                x.SetServiceName("ThreeBytes Quartz Service");
            });
        }

        public static void Main(string[] args)
        {
            Bootstrap();
            InitialiseHost().Run();
        }
    }
}
